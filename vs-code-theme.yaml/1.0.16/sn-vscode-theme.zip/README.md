# sn-theme-vscode

A theme for Standard Notes inspired by the VS Code Dark theme.

How to install:
- open Extensions manager on desktop / web client
- Import Extension
- https://marcaux.de/sn/vscode-theme/ext.json

![screenshot](https://github.com/hyphone/sn-theme-vscode/raw/master/screenshot.png)

